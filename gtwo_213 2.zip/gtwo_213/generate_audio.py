import os
from gtts import gTTS
from pydub import AudioSegment

# 单词列表
words = [
    'hello',   # word_0
    'world',   # word_1
    'python',  # word_2
    'coding',  # word_3
    'learn',   # word_4
    'study',   # word_5
    'program', # word_6
    'develop', # word_7
    'create',  # word_8
    'build',   # word_9
    'make'     # word_10
]

# 创建audio目录
if not os.path.exists('audio'):
    os.makedirs('audio')

# 生成并处理每个单词的音频
for i, word in enumerate(words):
    print(f'Processing {word}...')
    
    # 使用gTTS生成MP3
    tts = gTTS(text=word, lang='en', slow=False)
    mp3_path = f'audio/word_{i}.mp3'
    tts.save(mp3_path)
    
    # 转换为WAV格式并优化
    audio = AudioSegment.from_mp3(mp3_path)
    
    # 转换为8位、8kHz单声道WAV
    audio = audio.set_channels(1)  # 转换为单声道
    audio = audio.set_frame_rate(8000)  # 设置采样率为8kHz
    audio = audio.set_sample_width(1)  # 设置位深度为8位
    
    # 调整音量
    audio = audio + 6  # 增加6dB的音量
    
    # 保存为WAV文件
    wav_path = f'audio/word_{i}.wav'
    audio.export(wav_path, format='wav')
    
    # 删除临时MP3文件
    os.remove(mp3_path)
    
    print(f'Generated {wav_path}')

print('All audio files generated successfully!')