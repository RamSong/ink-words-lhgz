import os

def convert_bmp_to_array(bmp_file):
    with open(bmp_file, 'rb') as f:
        # 跳过BMP文件头（14字节）和DIB头（40字节）
        f.seek(54)
        # 读取图片数据
        data = f.read()
        # 将字节数据转换为十六进制字符串
        hex_data = [f'0x{b:02x}' for b in data]
        # 每行16个字节
        rows = [hex_data[i:i+16] for i in range(0, len(hex_data), 16)]
        # 格式化为C数组
        array_data = ',\n    '.join(', '.join(row) for row in rows)
        return array_data

def main():
    # 检查images目录是否存在
    if not os.path.exists('images'):
        print("Error: images目录不存在！")
        return

    # 获取所有BMP文件
    bmp_files = sorted([f for f in os.listdir('images') if f.endswith('.bmp')])
    if not bmp_files:
        print("Error: 没有找到BMP文件！")
        return

    # 生成word_images.cpp文件
    with open('word_images.cpp', 'w') as f:
        f.write('#include "word_images.h"\n#include <avr/pgmspace.h>\n\n')

        # 为每个图片生成数组
        for i, bmp_file in enumerate(bmp_files):
            array_data = convert_bmp_to_array(os.path.join('images', bmp_file))
            f.write(f'const unsigned char word_image_{i}[] PROGMEM = {{\n    {array_data}\n}};\n\n')

        # 生成图片数组指针数组
        f.write('const unsigned char* word_images[] PROGMEM = {\n')
        for i in range(len(bmp_files)):
            f.write(f'    word_image_{i},\n')
        f.write('};\n')

if __name__ == '__main__':
    main()
    print("图片转换完成！")