from PIL import Image, ImageDraw, ImageFont
import os

# 定义单词列表
words = [
    {"english": "apple", "phonetic": "/ˈæpl/", "chinese": "苹果", "partOfSpeech": "n."},
    {"english": "beautiful", "phonetic": "/ˈbjuːtɪfl/", "chinese": "美丽的", "partOfSpeech": "adj."},
    {"english": "computer", "phonetic": "/kəmˈpjuːtər/", "chinese": "计算机", "partOfSpeech": "n."},
    {"english": "diligent", "phonetic": "/ˈdɪlɪdʒənt/", "chinese": "勤奋的", "partOfSpeech": "adj."},
    {"english": "elephant", "phonetic": "/ˈelɪfənt/", "chinese": "大象", "partOfSpeech": "n."},
    {"english": "freedom", "phonetic": "/ˈfriːdəm/", "chinese": "自由", "partOfSpeech": "n."},
    {"english": "garden", "phonetic": "/ˈɡɑːrdn/", "chinese": "花园", "partOfSpeech": "n."},
    {"english": "happiness", "phonetic": "/ˈhæpinəs/", "chinese": "幸福", "partOfSpeech": "n."},
    {"english": "internet", "phonetic": "/ˈɪntərnet/", "chinese": "互联网", "partOfSpeech": "n."},
    {"english": "journey", "phonetic": "/ˈdʒɜːrni/", "chinese": "旅程", "partOfSpeech": "n."}
]

# 创建images目录（如果不存在）
if not os.path.exists('images'):
    os.makedirs('images')

# 设置图片尺寸（2.13寸墨水屏分辨率为250x122）
WIDTH = 250
HEIGHT = 122

# 加载字体（请确保这些字体文件存在，或替换为系统中可用的字体）
try:
    english_font = ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial Bold.ttf', 36)  # 英文单词字体
    phonetic_font = ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf', 20)  # 音标字体
    chinese_font = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 24)  # 中文字体
except:
    print("警告：无法加载指定字体，将使用默认字体")
    english_font = ImageFont.load_default()
    phonetic_font = ImageFont.load_default()
    chinese_font = ImageFont.load_default()

# 为每个单词生成图片
for i, word in enumerate(words):
    # 创建新图片，使用1位色彩模式（黑白）
    img = Image.new('1', (WIDTH, HEIGHT), 255)  # 255为白色背景
    draw = ImageDraw.Draw(img)
    
    # 绘制英文单词
    english_text = word['english']
    english_bbox = draw.textbbox((0, 0), english_text, font=english_font)
    english_width = english_bbox[2] - english_bbox[0]
    english_x = (WIDTH - english_width) // 2 + 30
    draw.text((english_x, 10), english_text, font=english_font, fill=0)
    
    # 绘制音标
    phonetic_text = word['phonetic']
    phonetic_bbox = draw.textbbox((0, 0), phonetic_text, font=phonetic_font)
    phonetic_width = phonetic_bbox[2] - phonetic_bbox[0]
    phonetic_x = (WIDTH - phonetic_width) // 2 + 30
    draw.text((phonetic_x, 50), phonetic_text, font=phonetic_font, fill=0)
    
    # 绘制分隔线
    draw.line([(50, 80), (WIDTH-10, 80)], fill=0, width=1)
    
    # 绘制词性和中文释义
    pos_cn_text = f"{word['partOfSpeech']} {word['chinese']}"
    pos_cn_bbox = draw.textbbox((0, 0), pos_cn_text, font=chinese_font)
    pos_cn_width = pos_cn_bbox[2] - pos_cn_bbox[0]
    pos_cn_x = (WIDTH - pos_cn_width) // 2 + 30
    draw.text((pos_cn_x, 90), pos_cn_text, font=chinese_font, fill=0)
    
    # 保存图片
    img.save(f'images/word_{i}.bmp', 'BMP')

print("所有单词卡片图片已生成完成！")