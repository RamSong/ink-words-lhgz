#ifndef WORD_IMAGES_H
#define WORD_IMAGES_H

// 单词卡片图片数量
const int TOTAL_IMAGES = 10;

// 图片尺寸
const int IMAGE_WIDTH = 250;
const int IMAGE_HEIGHT = 122;

// 图片数据将从images目录下的BMP文件转换而来
// 这里将在运行Python脚本后更新
extern const unsigned char* word_images[];

#endif // WORD_IMAGES_H